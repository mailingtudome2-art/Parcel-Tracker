# ป.303 Scanner — Vercel deployment (Google Gemini free tier)

A static site (`index.html`) plus one serverless function (`api/extract.js`)
that does the OCR call to Google's Gemini API. Your API key lives only on
the server side (as a Vercel environment variable) — it is never sent to
the browser.

## 1. Get a free Gemini API key

1. Go to https://aistudio.google.com/apikey
2. Sign in with a Google account and click "Create API key" — no credit
   card required.
3. Copy the key (starts with `AIza...`).

This gives you Google's free tier: no cost, but rate-limited (roughly
15 requests/minute and 1,000-1,500 requests/day depending on the model —
Google can change this at any time, check https://ai.google.dev/gemini-api/docs/rate-limits
for current numbers). Fine for personal use or a small team; if many
people use the site at once you may occasionally hit the daily/minute cap
and see a "ลองใหม่อีกครั้ง" (retry) error on that row.

## 2. Deploy to Vercel

**Option A — via GitHub (recommended)**
1. Push this folder to a new GitHub repository.
2. Go to https://vercel.com/new and import that repository.
3. Leave all build settings as default (no framework, no build command needed).
4. Go to **Project Settings → Environment Variables** and add:
   - Key: `GOOGLE_API_KEY` — Value: your key from step 1
   - (optional) Key: `GEMINI_MODEL` — only needed if the default model name
     stops working (see note below)
5. Redeploy (Vercel → Deployments → ⋯ → Redeploy) so the function picks up the new variable.

**Option B — via Vercel CLI**
```bash
npm i -g vercel
cd parcel-tracker-vercel
vercel               # follow the prompts to create/link a project
vercel env add GOOGLE_API_KEY production
vercel --prod
```

## 3. Test locally (optional)

```bash
npm i -g vercel
cd parcel-tracker-vercel
echo "GOOGLE_API_KEY=AIza..." > .env
vercel dev
```
Then open the local URL it prints.

## A note on the model name

Google renames/rotates its free "Flash" model more often than Anthropic
does. `api/extract.js` defaults to `gemini-flash-latest`, a floating
alias Google keeps pointed at a current Flash model, so you shouldn't
need to touch this normally. If uploads ever start failing with a
"Gemini API error (404)" message, it means that alias changed again —
check https://ai.google.dev/gemini-api/docs/models for the currently
recommended Flash model name, then set the `GEMINI_MODEL` environment
variable in Vercel to that name (no code change needed) and redeploy.

## Notes

- Data (extracted tracking numbers) is stored in the visitor's own browser
  (`localStorage`), not on a server — each device builds up its own list.
- Every image is resized/re-encoded to JPEG in the browser before upload,
  so HEIC/odd formats from phones convert automatically.
- Free tier is not available in the EU/UK/Switzerland as of this writing;
  double-check current terms at https://ai.google.dev/gemini-api/docs/pricing
  if that applies to you.
- If a sheet fails to read, the "retry" button on that row calls the API
  again without re-uploading.
- Want more headroom or fewer rate-limit hiccups later? You can switch
  back to Anthropic's API (paid, no free tier) — ask and I can swap the
  backend again.
